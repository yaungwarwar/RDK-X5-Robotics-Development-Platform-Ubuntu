# Manual deployment, upgrade and rollback — 0.1.2 release candidate

**Locally validated release candidate, approved for controlled physical upgrade testing.** Physical ARM64 deployment remains unvalidated. Preserve the failed `/home/sunrise/rdk-platform-0.1.1` and `/home/sunrise/rdk-backups/before-0.1.1` artifacts untouched. Review successful preparation before explicit activation.

These commands are for the user to run manually. The development agent has not connected to the X5, installed anything remotely, executed an upgrade or changed workstation/target services.

The running target is 0.1.0 at `/home/sunrise/rdk-platform`. **Use the upgrade transaction, not the initial installer and not an rsync overlay.** Both the new release and full old backup must be on the same filesystem for atomic directory swaps. Never copy a workstation venv/node_modules to ARM64.

## 1. Transfer a source-only release

In an existing target terminal/VNC session, create incoming/backup directories. This does not stop the application:

```bash
mkdir -p -m 700 /home/sunrise/rdk-incoming /home/sunrise/rdk-backups
```

On the workstation, verify the release checksum and transfer only the source archive/checksum:

```bash
cd /home/eve/rdk/rdk-platform/release
sha256sum -c rdk-control-center-0.1.2.tar.gz.sha256
rsync -av -- rdk-control-center-0.1.2.tar.gz rdk-control-center-0.1.2.tar.gz.sha256 sunrise@192.168.1.59:/home/sunrise/rdk-incoming/
```

Use `sunrise@192.168.127.10` instead for Ethernet. These are documentation-only SSH-backed transfer commands; the agent does not execute them. The archive excludes `.venv*`, node_modules, .git, Python/build caches, environment files, key/credential material, logs and generated local deployment data. It contains portable source and a frontend lockfile; native dependencies and the Docker image are built on ARM64.

On the target, verify and extract into a **new** sibling directory. The chained mkdir/extract intentionally refuses an existing staging path:

```bash
cd /home/sunrise/rdk-incoming
sha256sum -c rdk-control-center-0.1.2.tar.gz.sha256
mkdir -m 700 /home/sunrise/rdk-platform-0.1.2 && tar -xzf rdk-control-center-0.1.2.tar.gz --strip-components=1 -C /home/sunrise/rdk-platform-0.1.2
```

If the stage or backup name already exists, choose a new unused sibling name and use it consistently below. Do not delete an existing installation/backup or reuse a partially prepared stage to bypass a guard. Do not use `rsync --ignore-existing` to overlay releases.

## 2. Read-only compatibility preflight

Confirm the existing application is healthy through its current tunnel/terminal. Target software prerequisites are already installed from 0.1.0; no OS/vendor/Docker package replacement is performed.

```bash
cd /home/sunrise/rdk-platform-0.1.2
/usr/bin/python3 scripts/cgroup_compat.py --compose-file /home/sunrise/rdk-platform/compose.yaml --cpu-policy preserve --check
```

If the deployment uses additional Compose override files, supply each with repeated `--compose-file` in original order, here and in `upgrade.py prepare`. Preserve any RDK_NGINX_CONFIG environment selection used by that existing deployment.

The preflight:

- Accepts only a **local Unix-socket Docker endpoint**; remote TCP/SSH contexts are rejected. It never opens/exposes Docker TCP.
- Reads Docker's cgroup version/driver and the running dashboard's PID/cgroup paths. If no running container exists, it resolves the daemon parent from fixed daemon config/command-line observations or requires an explicit reviewed `--parent` path. Unknown/rootless/masked/custom split hierarchies fail safely rather than guessing.
- Reads cgroup mount metadata, effective controller/subtree propagation along the selected parent, controller interfaces and (when running) actual container leaf interfaces. Kernel compilation options alone never establish availability.
- Emits **RDK-COMPAT-001** when CPU quota delegation is unavailable and omits CPU quota settings from the generated config. It never enables subtree controllers or moves/stops watchdog/RT processes.
- Requires effective memory and PID controllers plus Docker limit support. Missing/denied evidence fails before activation. The configured 96 MiB memory and 64 PID limits remain; administrator positive limits are preserved.
- Validates non-root uid/gid 101, read-only root/config bind, ALL capabilities dropped, no-new-privileges, host networking without published ports/devices/socket mounts, and a loopback-only Nginx listener. The maintenance upgrade rejects LAN bindings for explicit separate review instead of silently changing exposure.

The v0.1.1 detector was physically exercised on the X5: cgroup v2 with systemd and `/system.slice` reported CPU quota unavailable, memory available and pids available. This does not validate the new upgrade path. The RT watchdog is not a conclusively established cause. Do not change its state, cgroup controls, kernel settings or Docker global configuration.

## 3. Prepare while 0.1.0 remains running

```bash
/usr/bin/python3 /home/sunrise/rdk-platform-0.1.2/scripts/upgrade.py prepare --release /home/sunrise/rdk-platform-0.1.2 --backup /home/sunrise/rdk-backups/before-0.1.2 --compose-file /home/sunrise/rdk-platform/compose.yaml
```

Preparation verifies target architecture/board/OS/Python/user, active service, native healthy 0.1.0 API/frontend, same-filesystem paths and storage space. It refuses an overlay, transferred venv, wrong installed/new version, unaccounted unit drop-ins, changed service user, weakened container isolation or an existing backup directory.

Before stopping anything it:

1. Copies the complete installed source and venv into `backup/source-and-venv`, preserving the original directory and running processes.
2. Backs up the actual unit and all accounted `/etc/systemd/system` drop-ins, saves the running frontend image with `docker image save`, records resolved previous Compose config and compatibility evidence.
3. Stores **standalone recovery scripts** under `backup/recovery`, outside both directories that will be swapped.
4. Copies current administrator config and Nginx files into the stage. Shipped staged default profiles are separately recorded; existing values are authoritative. Old JSON config files inherit new maintenance defaults without being rewritten. External RDK_CONFIG paths require separate review rather than blind migration.
5. Creates a new native ARM64 `.venv` in the stage, installs pinned application requirements, checks dependency consistency and validates the selected native config/imports. No global sudo pip or vendor package modification occurs.
6. Generates a new `.deployment/<unique-id>/compose.compat.json` and a compatibility report. This standalone config preserves memory/PID/security values and the operational manual quota workaround, even if the old source still had cpus. It adds **no new quota during upgrade**. Original Compose files are not rewritten.
7. Builds `rdk-control-center-dashboard:0.1.2` from staged source using the board's native Docker architecture. The old image is retained. Repairs generated venv text entrypoint paths for the final installation location.
8. Updates a private preparation journal throughout the process; writes the activation manifest after mandatory preparation succeeds, with unit/input/config/staged-source hashes. Rechecks prevent administrator edits made during/after preparation from being lost.

Review before apply:

```bash
cat /home/sunrise/rdk-backups/before-0.1.2/compatibility.json
/usr/bin/python3 /home/sunrise/rdk-platform-0.1.2/scripts/upgrade.py status --transaction /home/sunrise/rdk-backups/before-0.1.2
/usr/bin/python3 /home/sunrise/rdk-platform-0.1.2/scripts/upgrade.py diagnose --transaction /home/sunrise/rdk-backups/before-0.1.2
cat /home/sunrise/rdk-backups/before-0.1.2/transaction.json
ls -lh /home/sunrise/rdk-backups/before-0.1.2/frontend-image.tar
```

The journal's `new_compose` field identifies the generated file under the stage. Inspect it and confirm no cpus entry on this kernel, required memory/PID/security limits, correct localhost Nginx bind, image tag and original administrator mount/config selection. You can validate that exact file with `docker compose -p rdk-control-center -f /absolute/generated/file config -q` without activation.

A failed prepare leaves 0.1.0 running. It may leave a partial backup/staged venv or built new image; inspect and retain those artifacts, then use a fresh stage/backup for another attempt. The initial installer is not an upgrade mechanism.

## 4. Apply explicitly

Run the stable backup copy of the recovery tool so it remains available across directory moves:

```bash
/usr/bin/python3 /home/sunrise/rdk-backups/before-0.1.2/recovery/upgrade.py apply --transaction /home/sunrise/rdk-backups/before-0.1.2/transaction.json
```

Apply revalidates hashes and cgroup compatibility before stopping. It serializes upgrades with an application-specific user lock; no overlapping transactions. It stops **only rdk-control-center.service**, atomically moves the installed tree to `backup/previous-installation`, moves the stage to `/home/sunrise/rdk-platform`, starts the same unchanged unit, and recreates **only this Compose project's dashboard** with the generated configuration. Unit/drop-ins are not replaced; PrivateTmp, ProtectSystem, ProtectHome and all other controls remain intact. Ordinary interactive sudo is used only for this application's service stop/start.

Health checks require the expected version, native mode, fresh/healthy collector, loopback Nginx health endpoint and healthy dashboard container, within 90 seconds. A failure attempts automatic rollback and retains the journal/error/failed release for diagnosis. If rollback itself fails (for example Docker is unavailable), the error says so and leaves the stable recovery tool and artifacts intact; resolve that external failure and run explicit rollback below. Do not edit the journal to force success.

After success:

```bash
cd /home/sunrise/rdk-platform
./scripts/healthcheck.sh
./scripts/compose.sh ps
systemctl status rdk-control-center.service --no-pager
curl -fsS http://127.0.0.1:8089/api/v1/bpu
curl -fsS http://127.0.0.1:8089/api/v1/ros2
```

`compose.sh` resolves the generated active config from `.deployment/active.json`; use it for subsequent project `ps`, `logs`, `up`, `down` and rebuild operations. Bare `docker compose up` would ignore the selected compatibility profile and preserved administrator settings. No app command changes host networking/firewall/routes or existing listeners on 22, 111, 5900, 8000 or 11511.

A healthy collector does not prove a dedicated BPU sensor or ROS2 discovery is available. Review the new diagnostic fields separately and complete the physical checklist before declaring those paths accepted.

## 5. Explicit rollback, including interrupted activation

```bash
/usr/bin/python3 /home/sunrise/rdk-backups/before-0.1.2/recovery/upgrade.py rollback --transaction /home/sunrise/rdk-backups/before-0.1.2/transaction.json
```

This command is available even if the active installation path is temporarily absent after an interrupted directory move. It verifies unchanged unit/drop-ins, stops only this application, stops its new dashboard when present, retains the new tree as `backup/failed-release`, restores `previous-installation` at its original path (including the exact old venv/config/Compose workaround), reloads/tags the saved old frontend image, starts the unchanged unit and previous resolved Compose profile, and checks native 0.1.0 health. Original venv absolute paths work again at their original location. Already completed rollback is idempotent; repeated apply is refused. Refresh the browser after rollback to load the restored 0.1.0 frontend; an existing 0.1.2 tab also tolerates missing newer API diagnostic fields during reconnection.

The source/venv copy, image tar, unit/drop-in backups and journal remain for review. No Docker prune, vendor reinstall, unit hardening removal or unrelated process/service action is performed. If an administrator changed unit/drop-ins after prepare, the tool deliberately refuses to overwrite them; review the backup and reconcile those changes before retrying. Unit backups are evidence/recovery material; this workflow normally never changes the unit files at all.

For retry after rollback, extract the source archive into a fresh sibling stage and choose a new backup directory. This transaction explicitly supports 0.1.0 → 0.1.2; it refuses unknown/repeated installed versions. Future release scripts must declare their supported migration versions instead of bypassing this check.

## 6. Unchanged preferred access

Run manually on the workstation:

```bash
ssh -N -L 127.0.0.1:8088:127.0.0.1:8088 sunrise@192.168.1.59
```

Open `http://127.0.0.1:8088`; Ethernet uses `192.168.127.10`. The API stays on 127.0.0.1:8089. No authentication or TLS is added, and no public/LAN exposure is enabled by the upgrade. Existing optional LAN templates remain in source for separately reviewed deployments, not automatic maintenance activation.

## Fresh installation only

On a verified unused `/home/sunrise/rdk-platform` target directory:

```bash
cd /home/sunrise/rdk-platform
./scripts/install.sh --check
./scripts/install.sh
sudo systemctl enable --now rdk-control-center.service
./scripts/compose.sh up -d --no-build
./scripts/healthcheck.sh
```

The first installer retains its architecture/platform/user/path/existing-unit/venv guards. It performs read-only cgroup preflight before creating the venv and generates an exclusive compatibility bundle. CPU quota is added only when the effective controller supports it. Positive memory/PID limits and all controls remain required. Nothing starts automatically inside the installer. Stop/uninstall scripts use the selected generated config and affect only this project; uninstall retains source/venv/image for recovery. Never invoke this fresh installer over the operational 0.1.0 target.
